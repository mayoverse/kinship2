# pedigree other test

    Code
      lst
    Output
      $df
                               id           x0       y0
      1                   polygon  1.499999763 1.000000
      2                   polygon  0.499999820 2.000000
      3                   polygon  0.000000000 3.000000
      4                   polygon  0.499999995 4.000000
      5                   polygon  2.499999763 1.000000
      6                   polygon  1.499999820 2.000000
      7                   polygon  1.000000000 3.000000
      8                   polygon  2.499999820 2.000000
      9                   polygon  2.499999735 3.000000
      10                  polygon  3.499999820 2.000000
      11                  polygon  3.499999735 3.000000
      12                     mark  1.492807615 1.017857
      13                     mark  0.492807672 2.017857
      14                     mark -0.007192148 3.017857
      15                     mark  0.492807847 4.017857
      16                     mark  2.492807615 1.017857
      17                     mark  1.492807672 2.017857
      18                     mark  0.992807852 3.017857
      19                     mark  2.492807672 2.017857
      20                     mark  2.492807587 3.017857
      21                     mark  3.492807672 2.017857
      22                     mark  3.492807587 3.017857
      23                  polygon  1.499999763 1.000000
      24                  polygon  0.499999820 2.000000
      25                  polygon  0.000000000 3.000000
      26                  polygon  0.499999995 4.000000
      27                  polygon  2.499999763 1.000000
      28                  polygon  1.499999820 2.000000
      29                  polygon  1.000000000 3.000000
      30                  polygon  2.499999820 2.000000
      31                  polygon  2.499999735 3.000000
      32                  polygon  3.499999820 2.000000
      33                  polygon  3.499999735 3.000000
      34                     mark  1.507191912 1.017857
      35                     mark  0.507191968 2.017857
      36                     mark  0.007192148 3.017857
      37                     mark  0.507192143 4.017857
      38                     mark  2.507191912 1.017857
      39                     mark  1.507191968 2.017857
      40                     mark  1.007192148 3.017857
      41                     mark  2.507191968 2.017857
      42                     mark  2.507191883 3.017857
      43                     mark  3.507191968 2.017857
      44                     mark  3.507191883 3.017857
      45                     dead  1.482738607 1.039285
      46                     dead  0.482738664 2.039285
      47                     dead -0.017261156 3.039285
      48                     dead  2.482738607 1.039285
      49                     dead  1.482738664 2.039285
      50                     dead  2.482738579 3.039285
      51                       id  1.499999763 1.071540
      52                       id  0.499999820 2.071540
      53                       id  0.000000000 3.071540
      54                       id  0.499999995 4.071540
      55                       id  2.499999763 1.071540
      56                       id  1.499999820 2.071540
      57                       id  1.000000000 3.071540
      58                       id  2.499999820 2.071540
      59                       id  2.499999735 3.071540
      60                       id  3.499999820 2.071540
      61                       id  3.499999735 3.071540
      62             line_spouses  1.514384060 1.017857
      63             line_spouses  0.514384117 2.017857
      64             line_spouses  0.014384297 3.017857
      65             line_spouses  2.514384117 2.017857
      66            line_spouses2  0.014384297 3.021428
      67   line_children_vertical  0.499999820 2.000000
      68   line_children_vertical  3.499999820 2.000000
      69 line_children_horizontal  0.499999820 1.946429
      70          line_parent_mid  1.999999763 1.946429
      71          line_parent_mid  1.999999763 1.667857
      72          line_parent_mid  1.999999763 1.296429
      73   line_children_vertical  1.000000000 3.000000
      74 line_children_horizontal  1.000000000 2.946429
      75          line_parent_mid  1.000000000 2.946429
      76          line_parent_mid  1.000000000 2.667857
      77          line_parent_mid  0.999999820 2.296429
      78   line_children_vertical  2.499999735 3.000000
      79   line_children_vertical  3.499999735 3.000000
      80     label_children_twin3  2.999999735 2.973214
      81 line_children_horizontal  2.999999735 2.946429
      82          line_parent_mid  2.999999735 2.946429
      83          line_parent_mid  2.999999735 2.667857
      84          line_parent_mid  2.999999820 2.296429
      85   line_children_vertical  0.499999995 4.000000
      86 line_children_horizontal  0.499999995 3.946429
      87          line_parent_mid  0.499999995 3.946429
      88          line_parent_mid  0.499999995 3.667857
      89          line_parent_mid  0.500000000 3.296429
      90                      arc  0.000000000 3.000000
                 x1        y1       type    fill border
      1          NA        NA square_2_1     red  black
      2          NA        NA square_2_1   white  green
      3          NA        NA square_2_1     red  green
      4          NA        NA circle_2_1   white  black
      5          NA        NA circle_2_1   white  green
      6          NA        NA circle_2_1     red  green
      7          NA        NA circle_2_1   white  black
      8          NA        NA square_2_1   white  green
      9          NA        NA square_2_1     red  green
      10         NA        NA circle_2_1     red  black
      11         NA        NA square_2_1   white  green
      12         NA        NA       text   black   <NA>
      13         NA        NA       text   black   <NA>
      14         NA        NA       text   black   <NA>
      15         NA        NA       text   black   <NA>
      16         NA        NA       text   black   <NA>
      17         NA        NA       text   black   <NA>
      18         NA        NA       text   black   <NA>
      19         NA        NA       text   black   <NA>
      20         NA        NA       text   black   <NA>
      21         NA        NA       text   black   <NA>
      22         NA        NA       text   black   <NA>
      23         NA        NA square_2_2   white  black
      24         NA        NA square_2_2   white  green
      25         NA        NA square_2_2   white  green
      26         NA        NA circle_2_2   white  black
      27         NA        NA circle_2_2    grey  green
      28         NA        NA circle_2_2 #c300ff  green
      29         NA        NA circle_2_2 #c300ff  black
      30         NA        NA square_2_2 #c300ff  green
      31         NA        NA square_2_2   white  green
      32         NA        NA circle_2_2   white  black
      33         NA        NA square_2_2   white  green
      34         NA        NA       text   black   <NA>
      35         NA        NA       text   black   <NA>
      36         NA        NA       text   black   <NA>
      37         NA        NA       text   black   <NA>
      38         NA        NA       text   black   <NA>
      39         NA        NA       text   black   <NA>
      40         NA        NA       text   black   <NA>
      41         NA        NA       text   black   <NA>
      42         NA        NA       text   black   <NA>
      43         NA        NA       text   black   <NA>
      44         NA        NA       text   black   <NA>
      45 1.51726092 0.9964286   segments   black   <NA>
      46 0.51726098 1.9964286   segments   black   <NA>
      47 0.01726116 2.9964286   segments   black   <NA>
      48 2.51726092 0.9964286   segments   black   <NA>
      49 1.51726098 1.9964286   segments   black   <NA>
      50 2.51726089 2.9964286   segments   black   <NA>
      51         NA        NA       text   black   <NA>
      52         NA        NA       text   black   <NA>
      53         NA        NA       text   black   <NA>
      54         NA        NA       text   black   <NA>
      55         NA        NA       text   black   <NA>
      56         NA        NA       text   black   <NA>
      57         NA        NA       text   black   <NA>
      58         NA        NA       text   black   <NA>
      59         NA        NA       text   black   <NA>
      60         NA        NA       text   black   <NA>
      61         NA        NA       text   black   <NA>
      62 2.48561547 1.0178570   segments   black   <NA>
      63 1.48561552 2.0178570   segments   black   <NA>
      64 0.98561570 3.0178570   segments   black   <NA>
      65 3.48561552 2.0178570   segments   black   <NA>
      66 0.98561570 3.0214285   segments   black   <NA>
      67 0.49999982 1.9464289   segments   black   <NA>
      68 3.49999982 1.9464289   segments   black   <NA>
      69 3.49999982 1.9464289   segments   black   <NA>
      70 1.99999976 1.6678573   segments   black   <NA>
      71 1.99999976 1.2964286   segments   black   <NA>
      72 1.99999976 1.0178570   segments   black   <NA>
      73 1.00000000 2.9464289   segments   black   <NA>
      74 1.00000000 2.9464289   segments   black   <NA>
      75 1.00000000 2.6678573   segments   black   <NA>
      76 0.99999982 2.2964286   segments   black   <NA>
      77 0.99999982 2.0178570   segments   black   <NA>
      78 2.99999974 2.9464289   segments   black   <NA>
      79 2.99999974 2.9464289   segments   black   <NA>
      80         NA        NA       text   black   <NA>
      81 2.99999974 2.9464289   segments   black   <NA>
      82 2.99999974 2.6678573   segments   black   <NA>
      83 2.99999982 2.2964286   segments   black   <NA>
      84 2.99999982 2.0178570   segments   black   <NA>
      85 0.50000000 3.9464289   segments   black   <NA>
      86 0.50000000 3.9464289   segments   black   <NA>
      87 0.50000000 3.6678573   segments   black   <NA>
      88 0.50000000 3.2964286   segments   black   <NA>
      89 0.50000000 3.0178570   segments   black   <NA>
      90 2.49999974 3.0000000        arc   black   <NA>
         angle density cex label tips adjx adjy
      1     NA      NA  NA  <NA> <NA>   NA   NA
      2     NA      NA  NA  <NA> <NA>   NA   NA
      3     NA      NA  NA  <NA> <NA>   NA   NA
      4     NA      NA  NA  <NA> <NA>   NA   NA
      5     NA      NA  NA  <NA> <NA>   NA   NA
      6     NA      NA  NA  <NA> <NA>   NA   NA
      7     NA      NA  NA  <NA> <NA>   NA   NA
      8     NA      NA  NA  <NA> <NA>   NA   NA
      9     NA      NA  NA  <NA> <NA>   NA   NA
      10    NA      NA  NA  <NA> <NA>   NA   NA
      11    NA      NA  NA  <NA> <NA>   NA   NA
      12    NA      NA 0.5     1 <NA>   NA   NA
      13    NA      NA 0.5     0 <NA>   NA   NA
      14    NA      NA 0.5     1 <NA>   NA   NA
      15    NA      NA 0.5     0 <NA>   NA   NA
      16    NA      NA 0.5     0 <NA>   NA   NA
      17    NA      NA 0.5     1 <NA>   NA   NA
      18    NA      NA 0.5     0 <NA>   NA   NA
      19    NA      NA 0.5     0 <NA>   NA   NA
      20    NA      NA 0.5     1 <NA>   NA   NA
      21    NA      NA 0.5     1 <NA>   NA   NA
      22    NA      NA 0.5     0 <NA>   NA   NA
      23    NA      NA  NA  <NA> <NA>   NA   NA
      24    NA      NA  NA  <NA> <NA>   NA   NA
      25    NA      NA  NA  <NA> <NA>   NA   NA
      26    NA      NA  NA  <NA> <NA>   NA   NA
      27    NA      NA  NA  <NA> <NA>   NA   NA
      28    NA      NA  NA  <NA> <NA>   NA   NA
      29    NA      NA  NA  <NA> <NA>   NA   NA
      30    NA      NA  NA  <NA> <NA>   NA   NA
      31    NA      NA  NA  <NA> <NA>   NA   NA
      32    NA      NA  NA  <NA> <NA>   NA   NA
      33    NA      NA  NA  <NA> <NA>   NA   NA
      34    NA      NA 0.5     0 <NA>   NA   NA
      35    NA      NA 0.5     0 <NA>   NA   NA
      36    NA      NA 0.5     0 <NA>   NA   NA
      37    NA      NA 0.5     0 <NA>   NA   NA
      38    NA      NA 0.5  <NA> <NA>   NA   NA
      39    NA      NA 0.5     1 <NA>   NA   NA
      40    NA      NA 0.5     1 <NA>   NA   NA
      41    NA      NA 0.5     1 <NA>   NA   NA
      42    NA      NA 0.5     0 <NA>   NA   NA
      43    NA      NA 0.5     0 <NA>   NA   NA
      44    NA      NA 0.5     0 <NA>   NA   NA
      45    NA      NA 0.5  <NA> <NA>   NA   NA
      46    NA      NA 0.5  <NA> <NA>   NA   NA
      47    NA      NA 0.5  <NA> <NA>   NA   NA
      48    NA      NA 0.5  <NA> <NA>   NA   NA
      49    NA      NA 0.5  <NA> <NA>   NA   NA
      50    NA      NA 0.5  <NA> <NA>   NA   NA
      51    NA      NA 0.5   1_1 <NA>   NA   NA
      52    NA      NA 0.5   1_3 <NA>   NA   NA
      53    NA      NA 0.5   1_8 <NA>   NA   NA
      54    NA      NA 0.5  1_10 <NA>   NA   NA
      55    NA      NA 0.5   1_2 <NA>   NA   NA
      56    NA      NA 0.5   1_5 <NA>   NA   NA
      57    NA      NA 0.5   1_7 <NA>   NA   NA
      58    NA      NA 0.5   1_6 <NA>   NA   NA
      59    NA      NA 0.5   1_8 <NA>   NA   NA
      60    NA      NA 0.5   1_4 <NA>   NA   NA
      61    NA      NA 0.5   1_9 <NA>   NA   NA
      62    NA      NA 0.5  <NA> <NA>   NA   NA
      63    NA      NA 0.5  <NA> <NA>   NA   NA
      64    NA      NA 0.5  <NA> <NA>   NA   NA
      65    NA      NA 0.5  <NA> <NA>   NA   NA
      66    NA      NA 0.5  <NA> <NA>   NA   NA
      67    NA      NA 0.5  <NA> <NA>   NA   NA
      68    NA      NA 0.5  <NA> <NA>   NA   NA
      69    NA      NA 0.5  <NA> <NA>   NA   NA
      70    NA      NA 0.5  <NA> <NA>   NA   NA
      71    NA      NA 0.5  <NA> <NA>   NA   NA
      72    NA      NA 0.5  <NA> <NA>   NA   NA
      73    NA      NA 0.5  <NA> <NA>   NA   NA
      74    NA      NA 0.5  <NA> <NA>   NA   NA
      75    NA      NA 0.5  <NA> <NA>   NA   NA
      76    NA      NA 0.5  <NA> <NA>   NA   NA
      77    NA      NA 0.5  <NA> <NA>   NA   NA
      78    NA      NA 0.5  <NA> <NA>   NA   NA
      79    NA      NA 0.5  <NA> <NA>   NA   NA
      80    NA      NA 0.5     ? <NA>   NA   NA
      81    NA      NA 0.5  <NA> <NA>   NA   NA
      82    NA      NA 0.5  <NA> <NA>   NA   NA
      83    NA      NA 0.5  <NA> <NA>   NA   NA
      84    NA      NA 0.5  <NA> <NA>   NA   NA
      85    NA      NA 0.5  <NA> <NA>   NA   NA
      86    NA      NA 0.5  <NA> <NA>   NA   NA
      87    NA      NA 0.5  <NA> <NA>   NA   NA
      88    NA      NA 0.5  <NA> <NA>   NA   NA
      89    NA      NA 0.5  <NA> <NA>   NA   NA
      90    NA      NA 0.5  <NA> <NA>   NA   NA
      
      $par_usr
      $par_usr$usr
      [1] -0.0143843  3.5143841  4.1252641  1.0000000
      
      $par_usr$old_par
      $par_usr$old_par$xpd
      [1] TRUE
      
      
      $par_usr$boxw
      [1] 0.02876859
      
      $par_usr$boxh
      [1] 0.03571409
      
      $par_usr$labh
      [1] 0.02985481
      
      $par_usr$legh
      [1] 0.05357113
      
      

