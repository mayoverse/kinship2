# is_informative works with Pedigree

    The column test is not in the scales fill

