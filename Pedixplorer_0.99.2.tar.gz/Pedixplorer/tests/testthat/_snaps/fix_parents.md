# fix_parents works with number

    invalid class "Ped" object: dadid values '100', '200' should be in '1', '2', '3', '4', '5'...

# fix_parents works with character

    invalid class "Ped" object: momid values 'fam112' should be in 'fam101', 'fam102', 'fam103', 'fam104', 'fam105'...

# fix_parents works with sex errors

    invalid class "Ped" object: dadid values '2_209' should be in '2_201', '2_202', '2_203', '2_204', '2_205'...

# fix_parents works with famid

    invalid class "Ped" object: dadid values '2_209' should be in '1_101', '1_102', '1_103', '1_104', '1_105'...

