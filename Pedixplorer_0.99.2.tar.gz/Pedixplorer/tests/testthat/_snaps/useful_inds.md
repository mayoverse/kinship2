# useful_inds works with Pedigree

    The useful slot already has values in the Ped object and reset is set to FALSE

