# List of what need to be done for package

## Documentations of functions

- [x] AllClass.R
- [x] AllConstructor.R
- [x] AllAccessors.R
- [x] AllGeneric.R
- [x] AllValidity.R
- [x] Pedixplorer-package.R
- [x] align.R
- [x] alignped1.R
- [x] alignped2.R
- [x] alignped3.R
- [x] alignped4.R
- [x] auto_hint.R
- [x] best_hint.R
- [x] bit_size.R
- [x] data.R
- [x] descendants.R
- [x] family_check.R
- [x] find_avail_affected.R
- [x] find_avail_noninform.R
- [x] find_unavailable.R
- [x] fix_parents.R
- [x] generate_aff_inds.R
- [x] generate_colors.R
- [x] ibd_matrix.R
- [x] is_informative.R
- [x] kindepth.R
- [x] kinship.R
- [x] make_famid.R
- [x] min_dist_inf.R
- [x] norm_data.R
- [x] num_child.R
- [x] ped_to_legdf.R
- [x] ped_to_plotdf.R
- [x] plot.R
- [x] plot_fct.R
- [x] plot_fromdf.R
- [x] shrink.R
- [x] unrelated.R
- [x] useful_inds.R
- [x] utils.R

## For all class

- [x] General
  - [x] Class
  - [x] Constructor
  - [x] Getters
  - [x] Setters
  - [x] General methods
  - [x] See also

## Other

- [x] Take out addition of ind in ancestors compute Kindepth.
