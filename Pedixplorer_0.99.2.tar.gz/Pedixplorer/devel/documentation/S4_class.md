# The Pedigree S4 class

The different slots:

- ped
- derived
- rel
- meta
- scales
- hints

What to expose:
- meta
- input

What to not expose:
- id
- derived
- scales

Accessors:
- mcols
- fill_colors
- col_id
- col_derived
- col_input
