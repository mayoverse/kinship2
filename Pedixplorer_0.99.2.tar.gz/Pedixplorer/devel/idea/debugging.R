load_all()
ped <- Pedigree(data.frame(
    id = character(),
    dadid = character(),
    momid = character(),
    sex = numeric(),
    family = character(),
    avail = numeric(),
    affection = numeric()
))
