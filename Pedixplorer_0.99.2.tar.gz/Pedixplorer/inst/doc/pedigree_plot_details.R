## ---- help----------------------------------------------------------------------------------------
help(ped_to_plotdf)
help(plot_fromdf)

## ---- polygons, eval = FALSE----------------------------------------------------------------------
#  types <- c(
#      "square_1_1", # Whole square
#      "circle_2_1", # Semi circle first division
#      "diamond_3_2", # Third of diamond second division
#      "triangle_4_3" # Fourth of triangle third division
#  )
#  df <- plot_df <- data.frame(
#      x0 = c(1, 3, 5, 7), y0 = 1,
#      type = types, fill = c("red", "blue", "green", "yellow"),
#      border = "black",
#      angle = c(NA, 90, 0, 45),
#      density = c(NA, 10, 20, 40)
#  )
#  plot_fromdf(df, usr = c(0, 8, 0, 2))

## -------------------------------------------------------------------------------------------------
sessionInfo()

