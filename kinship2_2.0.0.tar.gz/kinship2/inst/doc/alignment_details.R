## ---- library_charge----------------------------------------------------------
library(kinship2)

## ---- auto_hint1, echo = FALSE, fig.dim = c(10, 8)----------------------------
#
# A simple pedigree to illustrate autohint's code
#
test1 <- data.frame(id = 1:11,
    sex = c("m", "f")[c(1, 2, 1, 2, 1, 1, 2, 2, 1, 2, 1)],
    dadid = c(0, 0, 1, 1, 1, 0, 0, 6, 6, 6, 9),
    momid = c(0, 0, 2, 2, 2, 0, 0, 7, 7, 7, 4)
)
ped1 <- pedigree(test1)

temp2 <- pedigree(test1, hints = list(
    order = c(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11)
))

par(mfrow = c(1, 2))
plot(temp2, title = "Before auto_hint")
plot(ped1, title = "After auto_hint")

## ---- align2, echo = FALSE, fig.dim = c(10, 8)--------------------------------
#
# The second, more complex test pedigree
#
test2 <- data.frame(id = c(1:13, 21:41),
                    dadid = c(0, 0, 1, 1, 1, 0, 0, 6, 6, 6, 0, 11, 11,
                        0, 0, 0, 0, 0, 0, 21, 21, 21, 23, 23, 25, 28,
                        28, 28, 28, 32, 32, 32, 32, 33
                    ),
                    momid = c(0, 0, 2, 2, 2, 0, 0, 7, 7, 7, 0, 5, 9,
                        0, 0, 0, 0, 0, 0, 22, 22, 22, 24, 24, 26, 31,
                        31, 31, 31, 29, 29, 29, 29, 13
                    ),
                    sex = c(1, 2, 1, 2, 2, 1, 2, 1, 2, 1, 1, 1, 2, 1,
                        2, 1, 2, 1, 2, 1, 1, 2, 2, 2, 1, 1, 1, 2, 2,
                        1, 2, 1, 1, 2
                    ))
ped2 <- pedigree(test2)
ped2a <- pedigree(test2, hints = list(
    order = seq_along(test2$id)
))
par(mfrow = c(1, 2))
plot(ped2a, title = "Before auto_hint")
plot(ped2, title = "After auto_hint")

## ---- align3, echo = FALSE, fig.dim = c(10, 8)--------------------------------
#
# A simple pedigree to illustrate autohint's code
#
test3 <- data.frame(id = 1:14,
                    sex = c("m", "f")[c(2, 1, 1, 1, 1, 1, 2,
                        2, 1, 2, 1, 2, 2, 1
                    )],
                    dadid = c(0, 6, 2, 2, 2, 0, 0, 11, 0, 9, 6, 0, 6, 11),
                    momid = c(0, 7, 1, 1, 1, 0, 0, 12, 0, 1, 7, 0, 7, 12),
                    affected = c(0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0))
ped3 <- pedigree(test3, hints = list(
    order = 1:14
))

test4 <- data.frame(id = 1:17,
                    sex = c("m", "f")[c(2, 1, 1, 2, 2, 1, 2, 1,
                        2, 2, 1, 2, 2, 1, 1, 2, 2
                    )],
                    dadid = c(0, 8, 6, 6, 0, 0, 0, 0, 11,
                        0, 0, 6, 0, 0, 0, 11, 14
                    ),
                    momid = c(0, 9, 5, 5, 0, 0, 0, 0, 10,
                        0, 0, 7, 0, 0, 0, 12, 5
                    ))

ped4 <- pedigree(test4, hints = list(
    order = 1:17
))

par(mfrow = c(1, 2))
plot(ped4)
plot(ped3)

