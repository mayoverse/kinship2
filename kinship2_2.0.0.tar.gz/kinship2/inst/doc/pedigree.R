## ----width_control, echo = FALSE------------------------------------------------------------------
options(width = 100)

## ----BiocManager_install, eval = FALSE------------------------------------------------------------
#  if (!requireNamespace("BiocManager", quietly = TRUE)) {
#      install.packages("BiocManager")
#  }
#  BiocManager::install("kinship2")

## ---- library_charge------------------------------------------------------------------------------
library(kinship2)

## ---- pedigree_creation---------------------------------------------------------------------------
data("sampleped")
sampleped[1:10, ]
ped <- pedigree(sampleped)
print(ped)

## ---- ped1----------------------------------------------------------------------------------------
ped1 <- ped[ped$ped$family == "1", ]
print(ped1)
summary(ped1)
plot(ped1)

## ---- ped1_title----------------------------------------------------------------------------------
plot(ped1, title = "Pedigree 1", legend = TRUE, leg_loc = c(5, 15, 4.5, 5))

## ---- datped2-------------------------------------------------------------------------------------
datped2 <- sampleped[sampleped$family == 2, ]
datped2[datped2$id %in% 203, "sex"] <- 2
datped2 <- datped2[-which(datped2$id %in% 209), ]

## ---- fixped2-------------------------------------------------------------------------------------
tryout <- try({
    ped2 <- pedigree(datped2)
})
fixped2 <- with(datped2, fix_parents(id, dadid, momid, sex))
fixped2
ped2 <- pedigree(fixped2)
plot(ped2)

## ---- calc_kinship--------------------------------------------------------------------------------
kin2 <- kinship(ped2)
kin2[1:9, 1:9]

## ---- kin_all-------------------------------------------------------------------------------------
ped <- pedigree(sampleped)
kin_all <- kinship(ped)
kin_all[1:9, 1:9]
kin_all[40:43, 40:43]
kin_all[42:46, 42:46]

## ---- kin_twins-----------------------------------------------------------------------------------
reltwins <- as.data.frame(rbind(c(206, 207, 1, 2), c(125, 126, 1, 1)))
colnames(reltwins) <- c("indId1", "indId2", "code", "family")
ped <- pedigree(sampleped, rel_df = reltwins)

kin_all <- kinship(ped)
kin_all[24:27, 24:27]
kin_all[46:50, 46:50]

## ---- status--------------------------------------------------------------------------------------
df2 <- sampleped[sampleped$family == 2, ]
names(df2)
df2$status <- c(1, 1, rep(0, 12))
ped2 <- pedigree(df2)
summary(ped2$ped$status)
plot(ped2)

## ---- labels--------------------------------------------------------------------------------------
ped2$ped$Names <- c(
    "John\nDalton", "Linda", "Jack", "Rachel", "Joe", "Deb",
    "Lucy", "Ken", "Barb", "Mike", "Matt",
    "Mindy", "Mark", "Marie\nCurie"
)
plot(ped2, label = "Names")

## ---- two_affection-------------------------------------------------------------------------------
df2$bald <- as.factor(c(0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 0, 0, 1))
ped2 <- pedigree(df2)
ped2 <- generate_colors(ped2, col_aff = "bald", add_to_scale = TRUE)
plot(ped2, legend = TRUE)

## ---- twins---------------------------------------------------------------------------------------
## create twin relationships
rel_df <- data.frame(
    indId1 = c(210, 212),
    indId2 = c(211, 213),
    code = c(1, 3),
    family = c(2, 2)
)
ped2 <- pedigree(df2, rel_df = rel_df)
plot(ped2)

## ---- inbreeding----------------------------------------------------------------------------------
indId <- 195:202
fatherId <- c(0, 0, 0, 196, 196, 0, 197, 199)
motherId <- c(0, 0, 0, 195, 195, 0, 198, 200)
gender <- c(2, 1, 1, 2, 1, 2, 1, 2)
ped3 <- data.frame(indId, fatherId, motherId, gender)
ped4df <- rbind.data.frame(ped2$ped[-c(1, 2), 2:5], ped3)
ped4 <- pedigree(ped4df)
plot(ped4)

## ---- spouse--------------------------------------------------------------------------------------
## create twin relationships
rel_df <- data.frame(
    indId1 = c(210, 212, 211),
    indId2 = c(211, 213, 212),
    code = c(1, 3, 4),
    family = c(2, 2, 2)
)
ped2 <- pedigree(df2, rel_df = rel_df)
plot(ped2)

## ---- plotped1------------------------------------------------------------------------------------
df1 <- sampleped[sampleped$family == 1, ]
relate1 <- data.frame(
    indId1 = 113,
    indId2 = 114,
    code = 4,
    family = 1
)
ped1 <- pedigree(df1,
    rel_df = relate1
)
plot(ped1)

## ---- ordering------------------------------------------------------------------------------------
df1reord <- df1[c(35:41, 1:34), ]
ped1reord <- pedigree(df1reord, rel_df = relate1)
plot(ped1reord)

## ---- ped2df, eval = FALSE------------------------------------------------------------------------
#  dfped2 <- as.data.frame(ped2)
#  dfped2

## ---- subset--------------------------------------------------------------------------------------
ped2_rm210 <- ped2[-10]
ped2_rm210$rel
ped2$rel

## ---- trim----------------------------------------------------------------------------------------
ped2_trim210 <- trim(ped2, "2_210")
ped2_trim210$ped$id
ped2_trim210$rel
ped2_trim_more <- trim(ped2_trim210, c("2_212", "2_214"))
ped2_trim_more$ped$id
ped2_trim_more$rel

## ---- shrink1-------------------------------------------------------------------------------------
set.seed(200)
shrink1_b30 <- shrink(ped1, max_bits = 30)
print(shrink1_b30)
plot(shrink1_b30$pedObj)

## ---- shrink2-------------------------------------------------------------------------------------
set.seed(10)
shrink1_b25 <- shrink(ped1, max_bits = 25)
shrink1_b25
plot(shrink1_b25$pedObj)

## ---- unrelateds----------------------------------------------------------------------------------
ped2 <- pedigree(df2)
set.seed(10)
set1 <- unrelated(ped2)
set1
set2 <- unrelated(ped2)
set2

## ---- unrelkin------------------------------------------------------------------------------------
df2
is_avail <- df2$id[df2$avail == 1]
kin2[is_avail, is_avail]

## -------------------------------------------------------------------------------------------------
sessionInfo()

