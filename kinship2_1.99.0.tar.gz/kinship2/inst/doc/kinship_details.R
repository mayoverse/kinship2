## ----eval=FALSE---------------------------------------------------------------
#  for (g in 1:max(depth)) {
#      indx <- which(depth == g)
#      kmat[indx, ] <- (kmat[mother[indx], ] + kmat[father[indx], ]) / 2
#      kmat[, indx] <- (kmat[, mother[indx]] + kmat[, father[indx], ]) / 2
#      for (j in indx) kmat[j, j] <- (1 + kmat[mother[j], father[j]]) / 2
#  }

## -----------------------------------------------------------------------------
sessionInfo()

